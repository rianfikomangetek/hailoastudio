<?php

	include 'head.php';
	include 'menu.php';

		//jika sudah mendapatkan parameter GET id dari URL
		if(isset($_GET['post_jasa'])){
			//membuat variabel $id untuk menyimpan id dari GET id di URL
			$id = $_GET['post_jasa'];
			
			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM jualan WHERE post_jasa='$id'") or die(mysqli_error($koneksi));
      

			//jika hasil query = 0 maka muncul pesan error
			if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
		}

		
  //saat tombol simpan ditindis
  if(isset($_POST['beli']))
  {
		// menangkap data yang dikirim dari form login
$username = $_POST['nama_produk'];
$password = md5($_POST['jumlah']);


// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"select * from pembeli where username='$username' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password di temukan pada database
if($cek > 0){

	$data = mysqli_fetch_assoc($login);
	
	$_SESSION["level"] = $data;
	// cek jika user login sebagai admin
	if($data['level']=="pembeli"){

		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "pembeli";
		// alihkan ke halaman dashboard admin
		header("location:pembeli/index.php");
	
	}else{

		// alihkan ke halaman login kembali
		header("location:login_pembeli.php?pesan=beli");
	}

	
}else{
	header("location:login_pembeli.php?pesan=beli");
}
  }

?>

<style>
.counter {
    width: 150px;
    margin-bottom: 100px;
	margin-left: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
	float:left;
	position:absolute;
}
.counter input {
    width: 50px;
    border: 0;
    line-height: 30px;
    font-size: 20px;
    text-align: center;
    background: #0052cc;
    color: #fff;
    appearance: none;
    outline: 0;
}
.counter span {
    display: block;
    font-size: 25px;
    padding: 0 10px;
    cursor: pointer;
    color: #0052cc;
    user-select: none;
}
</style>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_1.jpg);">
		<div class="overlay"></div>
		<div class="fh5co-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Detail Pesanan</h1>
							<h2>Home / Pesan</a></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div id="fh5co-couple" class="fh5co-section-gray">
		<div class="container">

  			<div class="row">
  				<div class="col-md-12">
				  	<div class="card">
						  	<div class="col-md-6">
								<img class="card-img-top" src="foto_produk/<?php echo $pecahkan['foto'];?>"  style="max-width:100%; height: auto;">
							</div>
							<div class="col-md-6">
							<div class="card-body">
								<h2 class="card-title"><?php echo $pecahkan['subject']; ?></h2>
									<hr>
								<h4>Deskripsi</h4>
									<p class="card-text"><?php echo $pecahkan['deskripsi']; ?></p>
								<h2><?php echo $hasil_rupiah = "Rp " . number_format($pecahkan['harga'],0,',','.'); ?></h2>
								
								<div class="counter">
								<span>Quantity: </span>
								<span class="down" onClick='decreaseCount(event, this)'>-</span>
										<input type="text" value="1">
									<span class="up" onClick='increaseCount(event, this)'>+</span>
								</div>

								<br><br>
								
								<div class="row">
									<div class="col-md-12">
										<a href="login.php?pesan=validasi" type="submit" class="btn btn-info btn-lg btn-block" name="beli"><i class="fa fa-user"></i><img src="images/shopping-cart.png" alt=""> Keranjang</a>
								
										<a href="https://api.whatsapp.com/send?phone=6282157680548&text=Min%20saya%20tertarik%20untuk%20membeli%<?php echo $pecahkan ['subject'];?>" type="submit" class="btn btn-success btn-lg btn-block" name="beli">Pesan WA</a>
									</div>
								</div>

							</div>	
						</div>					
					</div>
				</div>
		  	</div>

			<br><br>

			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
					<h2>Gallery!</h2>
				</div>
			</div>
			<div class="row row-bottom-padded-md">
				<div class="col-md-12">
					<ul id="fh5co-gallery-list">
						
						<li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(<?php echo $pecahkan['link2'] ;?>); "> 
						<a href="images/gallery-1.jpg">
							<div class="case-studies-summary">
								<span>1 Photos</span>
								
							</div>
						</a>
					</li>
					<li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(<?php echo $pecahkan['link1'] ;?>); ">
						<a href="#" class="color-2">
							<div class="case-studies-summary">
								<span>1 Photos</span>
							</div>
						</a>
					</li>
					</div>
				</div>
			</div>
		</div>
	</div>


	<?php include 'footer.php';?>
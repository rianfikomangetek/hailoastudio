<?php

	include 'head.php';
	include 'menu.php';

?>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_3.jpg);">
		<div class="overlay"></div>
		<div class="fh5co-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Toko HAILOA </h1>
						<div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div id="fh5co-couple" class="fh5co-section-gray">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
					<h2>Tentang Kami!</h2>
					<h3>28 November 2016. Gura Provinsi Maluku Utara, Kabupaten Halmahera Utara</h3>
					<p>Awal mula kami berdiri</p>
				</div>
			</div>
			<div class="couple-wrap animate-box">
				<div class="couple">					
					<div class="desc-bride">
						<h3>Sejarah Kami</h3>
						<p>Pada awalnya kami hanya membuka jasa make up untuk calon pengganti dan dengan berjalannya waktu serta penggalaman toko HAILOA menjadi sangat besar dan sudah menerima semua 
							jasa dalam persiapan acara nikahan atau disebut sebagai event organizer.</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	

	
	<?php
		include 'footer.php';
	?>


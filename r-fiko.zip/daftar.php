<?php

	include 'head.php';
	include 'menu.php';

//saat tombol simpan ditindis
if(isset($_POST['simpan']))
{

		$username	    	= htmlspecialchars($_POST['username']);
    	$password		 	= htmlspecialchars(md5($_POST['password']));
        $email			  	= htmlspecialchars($_POST['email']);
        $fullname			= htmlspecialchars($_POST['fullname']);
        $alamat		       	= htmlspecialchars($_POST['alamat']);
        $telepon	       	= htmlspecialchars($_POST['telepon']);
        $level		       	= htmlspecialchars($_POST['level']);
        


  //buat dan jalankan query INSERT
  $query = "INSERT INTO pembeli ";
  $query .= "(fullname, username, password, level, email, alamat, telepon)";
  $query .= "VALUES('$fullname','$username','$password','$level','$email','$alamat','$telepon')";

  echo "<script>alert('Pendaftaran Anda Telah Berhasil. Silahka Login')</script>";
  echo "<script>location='login.php'</script>";

  $result = mysqli_query($koneksi, $query);

  if(!$result)
  {
	die("Query gagal dijalankan: ".mysqli_errno($koneksi) ." - " .mysqli_error($koneksi));

  }
}

?>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_4.jpg);">
		<div class="overlay"></div>
		<div class="fh5co-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Daftar Akun</h1>
							<h2>Lakukan Pendaftaran Akun Untuk Memesan Layanan</a></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>


	<div class="fh5co-section">
		<div class="container">
			<div class="row">
				
				<div class="col-md-6 col-md-push-6 animate-box">
					<h3>Daftar</h3>
					<form action="daftar.php" method="post" class="login100-form validate-form">
				
					<?php 
					if(isset($_GET['pesan'])){
						if($_GET['pesan']=="gagal"){
							echo "<div class='alert alert-danger'>Aduh Boss Gagal Login</div>";
						}
					}
					?>
						

						<div class="row form-group">
							<div class="col-md-12">
								<label for="email">Username</label>
								<input type="text" id="email" class="form-control" name="username" placeholder="Username">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label for="subject">Password</label>
								<input type="text" id="subject" class="form-control" name="password" placeholder="Kata Sandi">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label for="text">Nama Lengkap</label>
								<input type="text" id="text" class="form-control" name="fullname" placeholder="Nama Anda">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label for="subject">Alamat</label>
								<textarea class="form-control" name="alamat" placeholder="Alamat"></textarea>
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label for="number">Nomor Telepon</label>
								<input type="number" id="number" class="form-control" name="telepon">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label for="email">Email</label>
								<input type="text" id="email" class="form-control" name="email" placeholder="Email Anda">
								<input type="hidden"  class="form-control" name="level" value="pembeli">
							</div>
						</div>

					
						<div class="form-group">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>

					</form>		
				</div>
				<div class="col-md-5 col-md-pull-5 animate-box">
					
					<div class="fh5co-contact-info">
					<div class="couple-wrap animate-box">
				<div class="couple-half">
					<div class="groom">
						<img src="images/groom.jpg" alt="groom" class="img-responsive">
					</div>
	
				</div>
				<p class="heart text-center"><i class="icon-heart2"></i></p>
				<div class="couple-half">
					<div class="bride">
						<img src="images/bride.jpg" alt="groom" class="img-responsive">
					</div>
			
				</div>
			</div>
					</div>

				</div>
			</div>
			
		</div>
	</div>

	<div id="map" class="fh5co-map"></div>
		<!-- END map -->

 <?php include 'footer.php';?>
<?php
	include 'head.php';
	include 'menu.php';

?>
	<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_2.jpg);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Promo &amp; Wedding</h1>
							<h2>Batas Waktu Promo Paket</h2>
							<div class="simply-countdown simply-countdown-one"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	
	<div id="fh5co-gallery" class="fh5co-section-gray">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
					<span>Pesan Layanan Kami</span>
					<h2>Paket Wedding</h2>
					<p>Sesuaikan pilih kamu untuk hari bahagia.</p>
				</div>
			</div>
			<div class="row row-bottom-padded-md">
				<div class="col-md-12">
					<ul id="fh5co-gallery-list">

					<!-- Pesanan post by alodospem -->
					<?php 
						if(isset($_GET['cari'])){
							$cari = $_GET['cari'];
							$data = mysqli_query($koneksi,"SELECT * FROM jualan where subject like '%".$cari."%'");				
						}else{
							$data = mysqli_query($koneksi,"SELECT * FROM jualan WHERE kategori ='promo' ORDER BY id_jual DESC");		
						}
						$no = 1;
						while($d = mysqli_fetch_array($data)){
						
						//seo link samaran 
						$judulnama_produk = preg_replace("/\s/","-",$d['post_jasa']);

						//menambahkan kata "berita" pada awal url dan ".php" pada akhir url
						$url_jasa = $judulnama_produk;
					
					?>
						
					<li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(foto_produk/<?php echo $d['foto'];?>); "> 
						<a href="<?php echo $url_jasa; ?>">
							<div class="case-studies-summary">
								<span style="font-size:16px;"><?php echo $hasil_rupiah = "Rp " . number_format($d['harga'],2,',','.'); ?></span>
								<h2><?php echo $d['subject'];?></h2>
							</div>
						</a>
					</li>
					
					<?php }?>
					</ul>		
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-counter" class="fh5co-bg fh5co-counter" style="background-image:url(images/img_bg_5.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="display-t">
					<div class="display-tc">
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-users"></i>
								</span>

								<?php
									$postingan   = mysqli_query($koneksi,"SELECT * FROM jualan"); 
									$beli = mysqli_query($koneksi, "SELECT * FROM beli WHERE statusku='lunas'") or die(mysqli_error());
									$ulasan = mysqli_query($koneksi, "SELECT * FROM keluhan") or die(mysqli_error());
									$pembeli   = mysqli_query($koneksi,"SELECT * FROM pembeli"); 

									$jumlahpostingan = mysqli_num_rows($postingan);
									$jumlahbeli = mysqli_num_rows($beli);
									$jumlahulasan = mysqli_num_rows($ulasan);
									$jumlahpembeli = mysqli_num_rows($pembeli);
								?>

								<span class="counter js-counter" data-from="0" data-to="<?php echo number_format($jumlahpembeli,0,",",".");  ?>" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">Jumlah Pasangan</span>

							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-user"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="<?php echo number_format($jumlahbeli,0,",",".");  ?>" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">Terjual</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-calendar"></i>
								</span>
								<span class="counter js-counter" data-from="0" data-to="<?php echo number_format($jumlahulasan,0,",",".");  ?>" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">Ulasan</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-clock"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="<?php echo number_format($jumlahpostingan,0,",",".");  ?>" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">Jumlah Layanan</span>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-testimonial">
		<div class="container">
			<div class="row">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<span>Ulasan Terbaik</span>
						<h2>Dari Costumer Kami</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 animate-box">
						<div class="wrap-testimony">
							<div class="owl-carousel-fullwidth">
							
							<?php
								$data = mysqli_query($koneksi,"SELECT * FROM keluhan WHERE bintang ='5' ORDER BY id_keluhan DESC");		
								
								$no = 1;
								while($d = mysqli_fetch_array($data)){
							?>
					
							
								<div class="item">
									<div class="testimony-slide active text-center">
										<figure>
											<img src="images/couple-1.jpg" alt="user">
										</figure>
										<span><?php echo $d['nama'];?> <a href="#" class="twitter">ulasan</a></span>
										<?php
										$bintang = $d['bintang'];
                        
										if ($bintang == "5") {
											echo "<strong>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											</strong>";
										  } elseif ($bintang >= "4") {
											echo "<strong>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star color-dark'></i>
											</strong>";
											
										  } elseif ( $bintang >= "3") {
											echo "<strong>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star color-dark'></i>
											<i class='fa fa-star color-dark'></i>
											</strong>";
										  } elseif ( $bintang >= "2") {
											echo "<strong>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star' style='color:gold'></i>
											<i class='fa fa-star color-dark'></i>
											<i class='fa fa-star color-dark'></i>
											<i class='fa fa-star color-dark'></i>
											</strong>";
										  }
										 elseif ( $bintang >= "1") {
										  echo "<strong>
										  <i class='fa fa-star' style='color:gold'></i>
										  <i class='fa fa-star color-dark'></i>
										  <i class='fa fa-star color-dark'></i>
										  <i class='fa fa-star color-dark'></i>
										  <i class='fa fa-star color-dark'></i>
										  </strong>";
										} else {
										  echo "<strong>
										  <i class='fa fa-star color-dark'></i>
										  <i class='fa fa-star color-dark'></i>
										  <i class='fa fa-star color-dark'></i>
										  <i class='fa fa-star color-dark'></i>
										  <i class='fa fa-star color-dark'></i>
										  </strong>";
										  }
									  
									
										?>
										<blockquote>
											<p><?php echo $d['keluhan'];?></p>
										</blockquote>
									</div>
								</div>
								<?php }?>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-services" class="fh5co-section-gray">
		<div class="container">
			
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Kebahagian Di Hari Spesial</h2>
					<p>Abadikan momen spesial anda bersama kami toko Hoiloa</p>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-calendar"></i>
						</span>
						<div class="feature-copy">
							<h3>Kami yang mengatur acara anda</h3>
							<p>Dengan mempercayakan proses resepsi pernikahan anda kepada kami. Kami yang akan mengatur seluruh struktur acara dan 
								anda tinggal duduk manis.
							</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-image"></i>
						</span>
						<div class="feature-copy">
							<h3>Photoshoot</h3>
							<p>Kami menyediakan photoshoot berpenggalaman dan hasil cetak yang sangat luar biasa.</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-video"></i>
						</span>
						<div class="feature-copy">
							<h3>Video Editing</h3>
							<p>Dari awal acara terus kami rekam moment berharga yang sungguh tak terlupakan untuk anda pasangan baru.</p>
						</div>
					</div>

				</div>

				<div class="col-md-6 animate-box">
					<div class="fh5co-video fh5co-bg" style="background-image: url(images/img_bg_3.jpg); ">
						<a href="https://vimeo.com/channels/staffpicks/93951774" class="popup-vimeo"><i class="icon-video2"></i></a>
						<div class="overlay"></div>
					</div>
				</div>
			</div>

			
		</div>
	</div>


	<div id="fh5co-started" class="fh5co-bg" style="background-image:url(images/img_bg_4.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Yuk percayakan kepada kami?</h2>
					<p>Hubungi kami melalui menu kontak diatas</p>
				</div>
			</div>
		<!---	<div class="row animate-box">
				<div class="col-md-10 col-md-offset-1">
					<form class="form-inline">
						<div class="col-md-4 col-sm-4">
							<div class="form-group">
								<label for="name" class="sr-only">Name</label>
								<input type="name" class="form-control" id="name" placeholder="Name">
							</div>
						</div>
						<div class="col-md-4 col-sm-4">
							<div class="form-group">
								<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Email">
							</div>
						</div>
						<div class="col-md-4 col-sm-4">
							<button type="submit" class="btn btn-default btn-block">I am Attending</button>
						</div>
					</form>
				</div>
			</div>--->
		</div>
	</div>

	<?php include 'footer.php';?>

<body>
		
<?php
$keranjang = mysqli_query($koneksi, "SELECT * FROM beli WHERE statusku='keranjang'") or die(mysqli_error());

$jumlahkeranjang= mysqli_num_rows($keranjang);
?>

	<div class="fh5co-loader"></div>
	
	<div id="page">
	<nav class="fh5co-nav" role="navigation">
		<div class="container">
			<div class="row">
				<div class="col-xs-2">
					<div id="fh5co-logo"><a href="index.html">Wedding<strong>.</strong></a></div>
				</div>
				<div class="col-xs-10 text-right menu-1">
					<ul>
						<li class="active"><a href="index.php">Home</a></li>
						<li class="active"><a href="tentang-kami.php">Tentang Kami</a></li>
						<li class="active"><a href="contact.php">Kontak</a></li>
						<li class="active" ><a href="keranjang.php"><img src="images/shopping-cart.png"> <sup><?php echo number_format($jumlahkeranjang,0,",",".");  ?></sup></a></li> | 
						<li class="active">
						<a href="#"><img src="images/programmer.png" alt=""> <?php echo $_SESSION['username']; ?></a></li>
						<li class="active">
								<?php
									//jika berhasil login
									if (isset($_SESSION["level"])) {
										echo'	
										| <a href="logout.php">Logout</a>
										';

									}
									else{
										echo'
										| <a href="#">Register</a>
										| <a href="#">Sign in</a>
										';
									}
								?>
						</li>
					
					</ul>
				</div>
			</div>
			
		</div>
	</nav>

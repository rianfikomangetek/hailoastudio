<?php
//session start 
session_start(); 

//jika berhasil login
if (!isset($_SESSION["level"])) {
  header("Location: ../login_pembeli.php");
  exit;
}

?>

<?php

include '../koneksi.php';

?>

<?php
//script untuk menampilkan data berdasarkan username
$id= $_SESSION["username"];

			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM beli WHERE username= '$id' ORDER BY id_beli DESC ");
            
            if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
      
		?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Takasimurah | Nota <?php echo $_SESSION["username"]; ?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="OneTech shop project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../styles/bootstrap4/bootstrap.min.css">
<link href="../plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../styles/product_styles.css">
<link rel="stylesheet" type="text/css" href="../styles/product_responsive.css">

<style>
	@media print{
		.main_nav, .header_search, .header_main, .top_bar_user, .contact_form_button {
			display : none;
		}

		.logout {
			display : none;
		}
	}

</style>

</head>

<body>

<div class="super_container">
	
	<!-- Header -->
	
	<header class="header">

				<!-- Top Bar -->

				<div class="top_bar">
			<div class="container">
				<div class="row">
					<div class="col d-flex flex-row">
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../images/phone.png" alt=""></div>+62 896 980 0 0752</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../images/mail.png" alt=""></div><a href="mailto:takasemurah@gmail.com">takasemurah@gmail.com</a></div>
						<div class="top_bar_content ml-auto">
							<div class="top_bar_user">
								<div class="user_icon"><img src="../images/user.svg" alt=""></div>
								<div><a href="#"><?php echo $_SESSION['username']; ?></a></div>
								<?php
									//jika berhasil login
									if (isset($_SESSION["level"])) {
										echo'	
										<div><a href="logout.php">Logout</a></div>
										';

									}
									else{
										echo'
										<div><a href="#">Register</a></div>
										<div><a href="#">Sign in</a></div>
										';
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>		
		</div>

		<!-- Header Main -->

		<div class="header_main">
			<div class="container">
				<div class="row">
										
					<!-- Logo -->
					<div class="col-lg-2 col-sm-3 col-3 order-1">
						<div class="logo_container">
							<div class="logo"><a href="#"> <img src="../foto_produk/takasemurah.png" alt=""></a></div>
						</div>
					</div>

					<!-- Search -->
					<div class="col-lg-6 col-12 order-lg-2 order-3 text-lg-left text-right">
						<div class="header_search">
							<div class="header_search_content">
								<div class="header_search_form_container">
									<form action="#" class="header_search_form clearfix">
										<input type="search" required="required" class="header_search_input" placeholder="Manjo Cari...">
										<div class="custom_dropdown">
											<div class="custom_dropdown_list">
												<span class="custom_dropdown_placeholder clc">Takasimurah</span>
												
												<ul class="custom_list clc">

												</ul>
											</div>
										</div>
										<button type="submit" class="header_search_button trans_300" value="Submit"><img src="images/search.png" alt=""></button>
									</form>
								</div>
							</div>
						</div>
					</div>

					<!-- Wishlist -->
									<div class="col-lg-4 col-9 order-lg-3 order-2 text-lg-left text-right">
						<div class="wishlist_cart d-flex flex-row align-items-center justify-content-end">
							<div class="wishlist d-flex flex-row align-items-center justify-content-end">
								<div class="wishlist_icon">
								</div>
							</div>

					<!-- Cart -->
							<div class="cart">
								<div class="cart_container d-flex flex-row align-items-center justify-content-end">
									<div class="cart_icon">
									</div>
									<div class="cart_content">
								</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
			<!-- Main Navigation -->

			<nav class="main_nav">
			<div class="container">
				<div class="row">
					<div class="col">
						
						<div class="main_nav_content d-flex flex-row">

							<!-- Categories Menu -->

							<div class="cat_menu_container">
								<div class="cat_menu_title d-flex flex-row align-items-center justify-content-start">
									<div class="cat_burger"><span></span><span></span><span></span></div>
									<div class="cat_menu_text">Pilih Penawaran</div>
								</div>

								<ul class="cat_menu">
									<li><a href="index.php">Promo <i class="fas fa-chevron-right ml-auto"></i></a></li>
									<li><a href="normal.php">Harga Normal<i class="fas fa-chevron-right"></i></a></li>
									<li><a href="diskon.php">Diskon<i class="fas fa-chevron-right"></i></a></li>
								</ul>
							</div>

							<!-- Main Nav Menu -->

							<div class="main_nav_menu ml-auto">
								<ul class="standard_dropdown main_nav_dropdown">
									<li><a href="index.php">Home<i class="fas fa-chevron-down"></i></a></li>
									<li><a href="tentang_kami.php">Tentang Kami<i class="fas fa-chevron-down"></i></a></li>
									<li><a href="contact.php">Contact<i class="fas fa-chevron-down"></i></a></li>
								</ul>
							</div>

							<!-- Menu Trigger -->

							<div class="menu_trigger_container ml-auto">
								<div class="menu_trigger d-flex flex-row align-items-center justify-content-end">
									<div class="menu_burger">
										<div class="menu_trigger_text">menu</div>
										<div class="cat_burger menu_burger_inner"><span></span><span></span><span></span></div>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</nav>
	</header>

	<!-- Single Blog Post -->
<br>
	<div class="single_post">
	<center><h3>Nota Pembelian</h3><br></center>
		<div class="container">
		<p><img src="../foto_produk/invoice.png" width="180" imageanchor="1" style="clear: right; float: right; margin-bottom: 1em; margin-right: 1em;">
			<div class="row">
				
			<form class="form-horizontal form-material" enctype="multipart/form-data" action="nota.php?id=<?php echo $id;?>" method="post">
			
                                    <div class="form-group">
                                        <label class="col-md-12">Nama Produk</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" value="<?php echo $pecahkan['nama_produk']; ?>">
                                        </div>
								  </div>
									
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Total Bayaran (Rp)</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" value="<?php echo $pecahkan['total_harga']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Warna</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" value="<?php echo $pecahkan['warna']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                    </div>
                                </form>
			</div>
			<br>
								<h3>Pembayaran Via Transfer Bank Di :</h3>
								<hr>
								<br>
								<p><img src="../images/bri.jpg" width="80" imageanchor="1" style="clear: left; float: left; margin-bottom: 1em; margin-right: 1em;"> 
								Nama : Pemilik <br>
								Kode : <b>002</b>  <br>
								Rek	 : <b>00234xxxxx</b>
								</p>
								<p style="text-align:right; font-size:25px;color:red;margin-top:-100px;"><strong>
								<?php
                                                      if(isset($pecahkan['status'])){
                                                        if($pecahkan['status'] == "lunas"){
                                                            
                                                            echo "<a href='#' class='btn btn-success btn-sm' name='status' value='belum'><strong>L U N A S</strong></a>";
                                                    
                                                        }
                                                          else {
                                                            $id_beli = $pecahkan['id_beli'];
                                                            echo "<a href='#' class='btn btn-danger btn-sm' name='status' value='lunas'>BELUM LUNAS</a>";
                                                          }
                                                        }
                                                ?>
								</strong></p>
						
								
							<div class="contact_form_button">
								<br><br><br>
									<h3>Kirim Bukti Pembayaran :</h3>
										<hr>
											<br>
												<center><button class="btn btn-success"><img src="../foto_produk/wa.png" width="40"><a href="https://api.whatsapp.com/send?phone=6281285932014" style="color:white;">Kirim Bukti</a></button></center>
							</div>
</p>
		</div>
	</div>



	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">


			</div>
		</div>
	</footer>
	<script>
		window.print();
	</script>
<script src="../js/jquery-3.3.1.min.js"></script>
<script src="../styles/bootstrap4/popper.js"></script>
<script src="../styles/bootstrap4/bootstrap.min.js"></script>
<script src="../plugins/greensock/TweenMax.min.js"></script>
<script src="../plugins/greensock/TimelineMax.min.js"></script>
<script src="../plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="../plugins/greensock/animation.gsap.min.js"></script>
<script src="../plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="../plugins/easing/easing.js"></script>
<script src="../js/regular_custom.js"></script>
</body>

</html>
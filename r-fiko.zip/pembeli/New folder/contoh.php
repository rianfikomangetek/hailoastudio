<?php
//session start 
session_start(); 

//jika berhasil login
if (!isset($_SESSION["level"])) {
  header("Location: ../login_member.php");
  exit;
}

?>


<?php

include "../koneksi.php";

?>

<?php
//script untuk menampilkan data berdasarkan username
$id= $_SESSION["username"];

			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM beli WHERE id_beli= $id");
            
            if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
      
		?>
<?php
//session start 
session_start(); 

//jika berhasil login
if (!isset($_SESSION["level"])) {
  header("Location: ../login_pembeli.php");
  exit;
}

?>

<?php

include '../koneksi.php';

?>

 <?php
		//jika sudah mendapatkan parameter GET id dari URL
		if(isset($_GET['id'])){
			//membuat variabel $id untuk menyimpan id dari GET id di URL
			$id = $_GET['id'];
			
			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM jualan WHERE id_jual='$id'") or die(mysqli_error($koneksi));
      

			//jika hasil query = 0 maka muncul pesan error
			if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
		}
		?>

<?php

  //saat tombol simpan ditindis
  if(isset($_POST['beli']))
  {
		$nama_produk 	= $_POST['nama_produk'];
		$username 		= $_POST['username'];
		$warna 			=  $_POST['warna1'];
		$jumlah 		= $_POST['jumlah'];
		$jumlah_harga 	= $_POST['jumlah']*$_POST['harga1'];
		
		
		    //buat dan jalankan query INSERT
			$query = "INSERT INTO beli ";
			$query .= "(nama_produk, username, warna, jumlah, total_harga)";
			$query .= "VALUES('$nama_produk','$username','$warna','$jumlah','$jumlah_harga')";

			echo "<script>alert('Data Berhasil Ditambah')</script>";
			echo "<script>location='nota.php'</script>";
		
			$result = mysqli_query($koneksi, $query);
		
			if(!$result)
			{
			  die("Query gagal dijalankan: ".mysqli_errno($koneksi) ." - " .mysqli_error($koneksi));
		
			}
		  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Takasemurah | <?php echo $pecahkan['subject']; ?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="OneTech shop project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../styles/bootstrap4/bootstrap.min.css">
<link href="../plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../styles/product_styles.css">
<link rel="stylesheet" type="text/css" href="../styles/product_responsive.css">

</head>

<body>

<div class="super_container">
	
	<!-- Header -->
	
	<header class="header">

				<!-- Top Bar -->

				<div class="top_bar">
			<div class="container">
				<div class="row">
					<div class="col d-flex flex-row">
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../images/phone.png" alt=""></div>+62 896 980 0 0752</div>
						<div class="top_bar_contact_item"><div class="top_bar_icon"><img src="../images/mail.png" alt=""></div><a href="mailto:takasemurah@gmail.com">takasemurah@gmail.com</a></div>
						<div class="top_bar_content ml-auto">
							<div class="top_bar_user">
								<div class="user_icon"><img src="../images/user.svg" alt=""></div>
								<div><a href="#"><?php echo $_SESSION['username']; ?></a></div>
								<?php
									//jika berhasil login
									if (isset($_SESSION["level"])) {
										echo'	
										<div><a href="logout.php">Logout</a></div>
										';

									}
									else{
										echo'
										<div><a href="#">Register</a></div>
										<div><a href="#">Sign in</a></div>
										';
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>		
		</div>

		<!-- Header Main -->

		<div class="header_main">
			<div class="container">
				<div class="row">

					<!-- Logo -->
					<div class="col-lg-2 col-sm-3 col-3 order-1">
						<div class="logo_container">
							<div class="logo"><a href="#"> <img src="../foto_produk/takasemurah.png" alt=""></a></div>
						</div>
					</div>

					<!-- Search -->
					<div class="col-lg-6 col-12 order-lg-2 order-3 text-lg-left text-right">
						<div class="header_search">
							<div class="header_search_content">
								<div class="header_search_form_container">
									<form action="#" class="header_search_form clearfix">
										<input type="search" required="required" class="header_search_input" placeholder="Manjo Cari...">
										<div class="custom_dropdown">
											<div class="custom_dropdown_list">
												<span class="custom_dropdown_placeholder clc">Takasemurah</span>
												
												<ul class="custom_list clc">

												</ul>
											</div>
										</div>
										<button type="submit" class="header_search_button trans_300" value="Submit"><img src="images/search.png" alt=""></button>
									</form>
								</div>
							</div>
						</div>
					</div>

					<!-- Wishlist -->
									<div class="col-lg-4 col-9 order-lg-3 order-2 text-lg-left text-right">
						<div class="wishlist_cart d-flex flex-row align-items-center justify-content-end">
							<div class="wishlist d-flex flex-row align-items-center justify-content-end">
								<div class="wishlist_icon">
								</div>
							</div>

					<!-- Cart -->
							<div class="cart">
								<div class="cart_container d-flex flex-row align-items-center justify-content-end">
									<div class="cart_icon">
									</div>
									<div class="cart_content">
								</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
			<!-- Main Navigation -->

			<nav class="main_nav">
			<div class="container">
				<div class="row">
					<div class="col">
						
						<div class="main_nav_content d-flex flex-row">

							<!-- Categories Menu -->

							<div class="cat_menu_container">
								<div class="cat_menu_title d-flex flex-row align-items-center justify-content-start">
									<div class="cat_burger"><span></span><span></span><span></span></div>
									<div class="cat_menu_text">Pilih Penawaran</div>
								</div>

								<ul class="cat_menu">
									<li><a href="index.php">Promo <i class="fas fa-chevron-right ml-auto"></i></a></li>
									<li><a href="normal.php">Harga Normal<i class="fas fa-chevron-right"></i></a></li>
									<li><a href="diskon.php">Diskon<i class="fas fa-chevron-right"></i></a></li>
								</ul>
							</div>

							<!-- Main Nav Menu -->

							<div class="main_nav_menu ml-auto">
								<ul class="standard_dropdown main_nav_dropdown">
									<li><a href="index.php">Home<i class="fas fa-chevron-down"></i></a></li>
									<li><a href="tentang_kami.php">Tentang Kami<i class="fas fa-chevron-down"></i></a></li>
									<li><a href="contact.php">Contact<i class="fas fa-chevron-down"></i></a></li>
								</ul>
							</div>

							<!-- Menu Trigger -->

							<div class="menu_trigger_container ml-auto">
								<div class="menu_trigger d-flex flex-row align-items-center justify-content-end">
									<div class="menu_burger">
										<div class="menu_trigger_text">menu</div>
										<div class="cat_burger menu_burger_inner"><span></span><span></span><span></span></div>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</nav>
	</header>

	<!-- Single Product -->

	<div class="single_product">
		<div class="container">
			<div class="row">

				<!-- Images -->
				<div class="col-lg-2 order-lg-1 order-2">
					<ul class="image_list">
						<li data-image="../foto_produk/<?php echo $pecahkan['foto'];?>"><img src="../foto_produk/<?php echo $pecahkan['foto'];?>" alt=""></li>
						<li data-image="<?php echo $pecahkan['link1']; ?>"><img src="<?php echo $pecahkan['link1']; ?>" alt=""></li>
						<li data-image="<?php echo $pecahkan['link2']; ?>"><img src="<?php echo $pecahkan['link2']; ?>" alt=""></li>
					</ul>
				</div>

				<!-- Selected Image -->
				<div class="col-lg-5 order-lg-2 order-1">
					<div class="image_selected"><img src="../foto_produk/<?php echo $pecahkan['foto'];?>" alt=""></div>
				</div>

				<!-- Description -->
				<div class="col-lg-5 order-3">
				
					<div class="product_description">
						<div class="product_category"><?php echo $pecahkan['kategori']; ?></div>
						<div class="product_name" value="<?php echo $pecahkan['subject']; ?>"><?php echo $pecahkan['subject']; ?></div>
						<div class="product_text"><p><?php echo $pecahkan['deskripsi']; ?></p></div>
						<div class="order_info d-flex flex-row">
							<form action="produk.php" action ="produk.php" method="post">
								<div class="clearfix" style="z-index: 1000;">
									  <input type="hidden" class="form-control" name="nama_produk" value="<?php echo $pecahkan['subject']; ?>">
									  <input type="hidden" class="form-control" name="username" value="<?php echo $_SESSION["username"]?>">
									<!-- Product Quantity -->
									<div class="product_quantity clearfix">
										<span>Quantity: </span>
										<input id="quantity_input" type="text" pattern="[0-9]*" value="1" name="jumlah">
										<div class="quantity_buttons">
											<div id="quantity_inc_button" class="quantity_inc quantity_control"><i class="fas fa-chevron-up"></i></div>
											<div id="quantity_dec_button" class="quantity_dec quantity_control"><i class="fas fa-chevron-down"></i></div>
										</div>
									</div>

									<!-- Product Color -->
									<ul class="product_color" name="warna1">
										<li>
											<span>Color: </span>
											<select name="warna1">
											<div class="color_mark_container"><div id="selected_color" class="color_mark"></div></div>
											<div class="color_dropdown_button"><i class="fas fa-chevron-down"></i></div>
		  									
											<ul class="color_list">
													<option style="color:black;"  value="merah">Merah</option>
													<option style="color:black;"  value="putih">Putih</option>
													<option style="color:black;"  value="pink">Pink</option>
													<option style="color:black;"  value="kuning">Kuning</option>
												</select>
											</ul>
										</li>
									</ul>
								</div>


		
								<div class="product_price" >Rp. <?php echo $pecahkan['harga']; ?></div>
								<input type="hidden" class="form-control" name="harga1" value="<?php echo $pecahkan['harga']; ?>">
								<div class="button_container">
									<button type="submit" class="button cart_button" name="beli">Beli</button>
								</div>
								
							</form>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	
	<!-- Copyright -->

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col">
					
					<div class="copyright_container d-flex flex-sm-row flex-column align-items-center justify-content-start">
						<div class="copyright_content"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="../js/jquery-3.3.1.min.js"></script>
<script src="../styles/bootstrap4/popper.js"></script>
<script src="../styles/bootstrap4/bootstrap.min.js"></script>
<script src="../plugins/greensock/TweenMax.min.js"></script>
<script src="../plugins/greensock/TimelineMax.min.js"></script>
<script src="../plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="../plugins/greensock/animation.gsap.min.js"></script>
<script src="../plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="../plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="../plugins/easing/easing.js"></script>
<script src="../js/product_custom.js"></script>
</body>

</html>
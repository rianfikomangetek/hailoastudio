<?php

	include 'head_keranjang.php';
	include 'menu.php';

		//jika sudah mendapatkan parameter GET id dari URL
		if(isset($_GET['id'])){
			//membuat variabel $id untuk menyimpan id dari GET id di URL
			$id = $_GET['id'];
			
			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM jualan WHERE id_jual='$id'") or die(mysqli_error($koneksi));
      

			//jika hasil query = 0 maka muncul pesan error
			if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
		}

	
  //saat tombol simpan ditindis
  if(isset($_POST['beli']))
  {
		$status			= $_POST['status'];
        $harga 	        = $_POST['harga'];
        $checkbox       = $_POST['checkbox'];  
		$jumlah_dipilih = count($checkbox);
        $jumlah_dipilih2 = count($harga);
        $jumlah_dipilih3 = count($status);
     
      for($x=0;$x<$jumlah_dipilih AND $jumlah_dipilih2 AND $jumlah_dipilih3;$x++){
     
		
            //buat dan jalankan query INSERT
            $ambil = mysqli_query($koneksi, "UPDATE beli SET 
            nama_produk='$checkbox[$x]', 
            total_harga='$harga[$x]',
            statusku='$status[$x]' where nama_produk='$checkbox[$x]'") or die(mysqli_error($koneksi));

			echo "<script>alert('Berhasil menambahkan ke nota')</script>";
			echo "<script>location='nota.php'</script>";
		
			$result = mysqli_query($koneksi, $query);
		
			if(!$result)
			{
			  die("Query gagal dijalankan: ".mysqli_errno($koneksi) ." - " .mysqli_error($koneksi));
		
			}
		  }
        }
?>

<style>

body {
    color: #000;
    overflow-x: hidden;
    height: 100%;
    background-color: #fff;
    background-repeat: no-repeat;
}

.plus-minus {
    position: relative;
}

.plus {
    position: absolute;
    top: -4px;
    left: 2px;
    cursor: pointer;
}

.minus {
    position: absolute;
    top: 8px;
    left: 5px;
    cursor: pointer;
}

.vsm-text:hover {
    color: #FF5252;
}

.book, .book-img {
    width: 120px;
    height: 180px;
    border-radius: 5px;
}

.book {
    margin: 20px 15px 5px 15px;
}

.border-top {
    border-top: 1px solid #EEEEEE !important;
    margin-top: 20px;
    padding-top: 15px;
}

.card {
    margin: 40px 0px;
    padding: 40px 50px;
    border-radius: 20px;
    border: none;
    box-shadow: 1px 5px 10px 1px rgba(0,0,0,0.2);
}

input, textarea {
    background-color: #F3E5F5;
    padding: 8px 15px 8px 15px;
    width: 100%;
    border-radius: 5px !important;
    box-sizing: border-box;
    border: 1px solid #F3E5F5;
    font-size: 25px !important;
    color: #000 !important;
    font-weight: 300;
}

input:focus, textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #9FA8DA;
    outline-width: 0;
    font-weight: 400;
}

button:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    outline-width: 0;
}

.pay {
    width: 80px;
    height: 40px;
    border-radius: 5px;
    border: 1px solid #673AB7;
    margin: 10px 20px 10px 0px;
    cursor: pointer;
    box-shadow: 1px 5px 10px 1px rgba(0,0,0,0.2);
}

.gray {
    -webkit-filter: grayscale(100%);
    -moz-filter: grayscale(100%);
    -o-filter: grayscale(100%);
    -ms-filter: grayscale(100%);
    filter: grayscale(100%);
    color: #E0E0E0;
}

.gray .pay {
    box-shadow: none;
}

#tax {
    border-top: 1px lightgray solid;
    margin-top: 10px;
    padding-top: 10px;
}

.btn-blue {
    border: none;
    border-radius: 10px;
    background-color: #673AB7;
    color: #fff;
    padding: 8px 15px;
    margin: 20px 0px;
    cursor: pointer;
}

.btn-blue:hover {
    background-color: #311B92;
    color: #fff;
}

#checkout {
    float: left;
}

#check-amt {
    float: right;
}

@media screen and (max-width: 768px) {
    .book, .book-img {
        width: 100px;
        height: 150px;
    }

    .card {
        padding-left: 15px;
        padding-right: 15px;
    }

    .mob-text {
        font-size: 13px;
    }

    .pad-left { 
        padding-left: 20px;
    }
}


    /* table nota */
    #customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: gray;
  color: white;
}
</style>


	<header id="fh5co-header" class="fh5co-cover" role="banner" style="height:100px;">
		<div class="overlay"></div>
		<div class="fh5co-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					
				</div>
			</div>
		</div>
	</header>

	<div id="fh5co-couple" class="fh5co-section-gray">
		<div class="container">
        <form enctype="multipart/form-data" action="nota.php" method="post">
                          
        <?php
        
        $cekstatus = mysqli_query($koneksi, "SELECT * FROM beli where username='$usernamesss' and statusku='belum'") or die(mysqli_error($koneksi)); //mengambil query pada tabel jemaat
        

        $cekidentitas = mysqli_fetch_assoc($cekstatus);
                            
    ?>                    

		<div class="container-fluid">
            <h1 class="mt-4">Nota / Invoice Pesananmu</h1>
        <hr>

        <div class="row">
            <div class="col-md-6">
                <h4>Untuk : <strong style="color:skyblue;font-size:25px;"><?php echo $identitas['username'];?></strong></h4>
                <h4> <?php echo $identitas['alamat'];?></h4>
                <h4><i class="fa fa-phone"></i> <?php echo $identitas['telepon'];?></h4>
            </div>

            <div class="col-md-6">
                <h4>Invoice</h4>
                <h4><i class="fa fa-calendar"></i> <?php echo date('Y-m-d'); ?></h4>
                <h4>Status : <?php echo $cekidentitas['statusku'];?></h4>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">

            <table id="customers">
  <tr>
    <th>No.</th>
    <th>Nama Pesanan</th>
    <th>Jumlah</th>
    <th>Harga</th>
    <th>Subtotal</th>
  </tr>

  <?php
		$no = 1;
        $usernameku = $_SESSION['username'];
        
        $ambil = mysqli_query($koneksi, "SELECT * FROM beli INNER JOIN jualan ON beli.nama_produk = jualan.subject where username='$usernameku' and statusku='belum'") or die(mysqli_error($koneksi)); //mengambil query pada tabel jemaat
        $total = 0;
        $tot_bayar = 0;

        while($pecahkan = mysqli_fetch_assoc($ambil)){ //perulangan 
            $total = $pecahkan['total_harga']; 

            $tot_bayar += $total;
                            
    ?>
  <tr>
    <td><?php echo $no++;?></td>
    <td><?php echo $pecahkan['nama_produk']; ?></td>
    <td><?php echo $pecahkan['jumlah']; ?> </td>
    <td><?php echo $hasil_rupiah = "Rp " . number_format($pecahkan['harga'],0,',','.'); ?></td>
    <td><?php echo $hasil_rupiah = "Rp " . number_format($pecahkan['total_harga'],0,',','.'); ?></td>
  </tr>
  
	<?php }?>
</table>

            </div>
        </div>


	

        <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                <div class="row">
                    <div class="col-lg-3 radio-group">
                        
                        <div class="row d-flex px-3 radio gray">
                         <p>Upload Bukti Transfer</p>   
                        <input type="file" name="gambar" >
                        </div>
                        
                    </div>
                    <div class="col-lg-5"> <br>
                        <p>Simpan bukti pembayaran</p>
                        <a href="nota_cetak.php" class="btn-block btn-secondary"style="padding-top:5px;margin-top:0px;text-align:center;color:white;text-decoration:none;font-size:28px;border-radius:5px;" >Cetak Nota</a>
                    </div>
                    <div class="col-lg-4 mt-2">
                        
                        <div class="row d-flex justify-content-between px-4" id="tax">
                            <p class="mb-1 text-left">Total Pembayaran</p>
                            <h6 class="mb-1 text-right">Rp. <?php echo number_format($tot_bayar,0,',','.'); ?></h6>
                        </div>
                                              

                        <button class="btn-block btn-blue" type="submit" name="beli">
                            <span>
                                <span id="checkout">Beli Sekarang</span>
                            <span id="check-amt">Rp. <?php echo number_format($tot_bayar,0,',','.'); ?></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
									
  		
			</form>
			<br><br>

			
		</div>
	</div>

	<script>
	$(document).ready(function(){

$('.radio-group .radio').click(function(){
    $('.radio').addClass('gray');
    $(this).removeClass('gray');
});

$('.plus-minus .plus').click(function(){
    var count = $(this).parent().prev().text();
    $(this).parent().prev().html(Number(count) + 1);
});

$('.plus-minus .minus').click(function(){
    var count = $(this).parent().prev().text();
    $(this).parent().prev().html(Number(count) - 1);
});

});
	</script>

	<?php include 'footer.php';?>
		


<?php

session_start();
session_unset(); //untuk memastikan seassionnya hilang
session_decode();

//kase bale ka login
header("Location: index.php");
    exit;

?>
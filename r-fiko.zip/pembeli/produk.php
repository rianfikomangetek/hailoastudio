<?php

	include 'head.php';
	include 'menu.php';

		//jika sudah mendapatkan parameter GET id dari URL
		if(isset($_GET['post_jasa'])){
			//membuat variabel $id untuk menyimpan id dari GET id di URL
			$id = $_GET['post_jasa'];
			
			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM jualan WHERE post_jasa='$id'") or die(mysqli_error($koneksi));
      

			//jika hasil query = 0 maka muncul pesan error
			if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
		}

	
  //saat tombol simpan ditindis
  if(isset($_POST['beli']))
  {
		$nama_produk 	= htmlspecialchars($_POST['nama_produk']);
		$username 		= htmlspecialchars($_POST['username']);
		$harga 			= htmlspecialchars($_POST['harga']);
		$jumlah 		= htmlspecialchars($_POST['jumlah']);
		$jumlah_harga 	= $jumlah*$harga;
		$status			= htmlspecialchars($_POST['status']);
		$level			= htmlspecialchars($_POST['level']);
		
		
		    //buat dan jalankan query INSERT
			$query = "INSERT INTO beli ";
			$query .= "(nama_produk, username, jumlah, total_harga, statusku, level)";
			$query .= "VALUES('$nama_produk','$username','$jumlah','$jumlah_harga','$status','$level')";

			echo "<script>alert('Data Berhasil Ditambah')</script>";
			echo "<script>location='keranjang.php'</script>";
		
			$result = mysqli_query($koneksi, $query);
		
			if(!$result)
			{
			  die("Query gagal dijalankan: ".mysqli_errno($koneksi) ." - " .mysqli_error($koneksi));
		
			}
		  }

?>

<style>
.counter {
    width: 150px;
    margin-bottom: 100px;
	margin-left: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
	float:left;
	position:absolute;
}
.counter input {
    width: 50px;
    border: 0;
    line-height: 30px;
    font-size: 20px;
    text-align: center;
    background: #0052cc;
    color: #fff;
    appearance: none;
    outline: 0;
}
.counter span {
    display: block;
    font-size: 25px;
    padding: 0 10px;
    cursor: pointer;
    color: #0052cc;
    user-select: none;
}
</style>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_1.jpg);">
		<div class="overlay"></div>
		<div class="fh5co-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Detail Pesanan</h1>
							<h2>Home / Pesan</a></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div id="fh5co-couple" class="fh5co-section-gray">
		<div class="container">
		<form action="produk.php" method="post">
							
  			<div class="row">
  				<div class="col-md-12">
				  	<div class="card">
						  	<div class="col-md-6">
								<img class="card-img-top" src="../foto_produk/<?php echo $pecahkan['foto'];?>"  style="max-width:100%; height: auto;">
							</div>
							<div class="col-md-6">
							<div class="card-body">
								<h2 class="card-title"><?php echo $pecahkan['subject']; ?></h2>
									<hr>
								<h4>Deskripsi</h4>
									<p class="card-text"><?php echo $pecahkan['deskripsi']; ?></p>
								<h2><?php echo $hasil_rupiah = "Rp " . number_format($pecahkan['harga'],0,',','.'); ?></h2>
								
								<div class="counter">
								<span>Quantity: </span>
								<span class="down" onClick='decreaseCount(event, this)'>-</span>
										<input type="text" value="1" name="jumlah">
										<input type="hidden" class="form-control" name="nama_produk" value="<?php echo $pecahkan['subject']; ?>">
									  	<input type="hidden" class="form-control" name="username" value="<?php echo $_SESSION["username"]?>">
									  	<input type="hidden" class="form-control" name="status" value="keranjang" >
										<input type="hidden" class="form-control" name="level" value="pembeli" >
										<input type="hidden" class="form-control" name="harga" value="<?php echo $pecahkan['harga'] ;?>" >
									
									<span class="up" onClick='increaseCount(event, this)'>+</span>
								</div>

								<br><br>
								
								<div class="row">
									<div class="col-md-12">
										<button type="submit" name="beli" class="btn btn-info btn-lg btn-block"><i class="fa fa-user"></i><img src="images/shopping-cart.png" alt=""> Keranjang</button>
								
										<a href="https://api.whatsapp.com/send?phone=6282157680548&text=Min%20saya%20tertarik%20untuk%20membeli%<?php echo $pecahkan ['subject'];?>" type="submit" class="btn btn-success btn-lg btn-block" name="beli">Pesan WA</a>
									</div>
								</div>

							</div>	
						</div>					
					</div>
				</div>
		  	</div>
			</form>
			<br><br>

			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
					<h2>Gallery!</h2>
				</div>
			</div>
			<div class="row row-bottom-padded-md">
				<div class="col-md-12">
					<ul id="fh5co-gallery-list">
						
						<li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(<?php echo $pecahkan['link2'] ;?>); "> 
						<a href="images/gallery-1.jpg">
							<div class="case-studies-summary">
								<span>1 Photos</span>
								
							</div>
						</a>
					</li>
					<li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(<?php echo $pecahkan['link1'] ;?>); ">
						<a href="#" class="color-2">
							<div class="case-studies-summary">
								<span>1 Photos</span>
							</div>
						</a>
					</li>
					</div>
				</div>
			</div>
		</div>
	</div>


	<?php include 'footer.php';?>


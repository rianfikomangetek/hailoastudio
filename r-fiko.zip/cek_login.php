<?php 
// mengaktifkan session pada php
session_start();

//jika sudah login tak bisa kembali kemari
if (isset($_SESSION["level"])) {
    header("Location: admin/dashboard.php");
}

// menghubungkan php dengan koneksi database
include 'koneksi.php';



// menangkap data yang dikirim dari form login
$namauser = $_POST['username'];
$username = mysqli_real_escape_string($koneksi, $namauser);

$kodepassword = md5($_POST['password']);
$password = mysqli_real_escape_string($koneksi, $kodepassword);


// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"select * from user where username='$username' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password di temukan pada database
if($cek > 0){

	$data = mysqli_fetch_assoc($login);
	
	$_SESSION["level"] = $data;
	// cek jika user login sebagai admin
	if($data['level']=="admin"){

		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "admin";
		// alihkan ke halaman dashboard admin
		header("location:admin/dashboard.php");

	// cek jika user login sebagai karyawan
	}else if($data['level']=="kasir"){
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "kasir";
		// alihkan ke halaman dashboard karyawan
		header("location:kasir/dashboard.php");

	}else{

		// alihkan ke halaman login kembali
		header("location:login.php?pesan=gagal");
	}

	
}else{
	header("location:login.php?pesan=gagal");
}



?>
<?php
error_reporting(0);
//session start 
session_start(); 


include "../koneksi.php";

if (!isset($_SESSION["level"])) {
  echo "<script>location='../index.php'</script>"; 
  exit;
}else  if ($cekss['level'] == 'pembeli') {
  echo "<script>location='../pembeli/index.php'</script>";   
  exit;
}

?>
<?php

			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$identitas = mysqli_query($koneksi, "SELECT * FROM settings") or die(mysqli_error($koneksi));
			$webidentitas = mysqli_fetch_assoc($identitas);

?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

        <!--script pencarian data table otomatis coy-->
        <script src="datatable/jquery-3.1.0.js"></script>
    <script src="datatable/jquery.dataTables.min.js"></script>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../foto_produk/wedding.png">
    <title><?php echo $webidentitas['judul_website'] ;?></title>
    <!-- Custom CSS -->
    <link href="assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
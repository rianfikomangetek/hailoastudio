<?php

include "head.php";
include "menu.php";

?>
 
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                          <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->

                    
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-12 col-xlg-9 col-md-7">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!-- title -->
                                <div class="d-md-flex align-items-center">
                                    <div>
                                        <h4 class="card-title">Laporan Transaksi</h4>
                                    </div>
                                    
                                    <div class="ml-auto">
                                        <div class="dl">
                                            <a href="cetak_laporan.php" class="btn btn-success btn-sm">Cetak Laporan</a> 
                                       </div>
                                    </div>
                                </div>
                                <!-- title -->
                            </div>
                            <div class="table-responsive">
                                <table id="tabel-data" class="table v-middle">
                                    <thead>
                                        <tr class="bg-light">
                                            <th class="border-top-0">No.</th>
                                            <th class="border-top-0">Nama Produk</th>
                                            <th class="border-top-0">Penginput</th>
                                            <th class="border-top-0">Jumlah</th>
                                            <th class="border-top-0">Total Harga</th>
                                            <th class="border-top-0">Username</th>
                                            <th class="border-top-0">Status</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                     
                                        $nomor=1; //mengurutkan nomor , sambungan ++ dibawah
                                        
                                        $ambil = mysqli_query($koneksi, "SELECT * FROM beli ORDER BY id_beli DESC") or die(mysqli_error($koneksi)); //mengambil query pada tabel jemaat
                                        
                                        while($pecahkan = mysqli_fetch_assoc($ambil)){ //perulangan 

                                        ?>
                                                                            
                                            <tr>
                                            <td> <?php echo $nomor;?> </td>
                                            <td> <?php echo $pecahkan['nama_produk'];?> </td>
                                            <td> <?php echo $pecahkan['username'];?> </td>
                                            <td> <?php echo $pecahkan['jumlah'];?> </td>
                                            <td> <?php echo $pecahkan['total_harga'];?> </td>
                                            <td> <?php echo $pecahkan['username'];?> </td>
                                            <td> 
                                            <?php
                                                      if(isset($pecahkan['statusku'])){
                                                        if($pecahkan['statusku'] == "lunas"){
                                                            
                                                            echo "<a href='#' class='btn btn-success btn-sm' name='status' value='belum'>Lunas</a>";
                                                    
                                                        }
                                                          else {
                                                            $id_beli = $pecahkan['id_beli'];
                                                            echo "<a href='konfirmasi.php?id=$id_beli' class='btn btn-warning btn-sm' name='status' value='lunas'>Belum Lunas</a>";
                                                          }
                                                        }
                                                ?>    
                                            </td>
                                            <td>    
                                                <a href="batal_produk.php?id=<?php echo $pecahkan['id_beli']?>" class="btn btn-danger btn-sm">Batalkan</a>
                                            </td>
                                            </tr>
                                        
                                            <?php $nomor++; //untuk menambah 1 angka untuk nomor urut?>
                                    <?php } ?>
                                            
  
                     </tbody>
                     <!--ini depe script data table-->
                          <script>
                          $(document).ready(function(){
                              $('#tabel-data').DataTable();
                          });
                      </script>

                    </table>
                    
                  </div>
                </div>
              </div>
            </div>
        </div>
<?php

include "footer.php";
?>
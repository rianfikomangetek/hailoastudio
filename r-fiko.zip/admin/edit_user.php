<?php

include "head.php";
include "menu.php";

//menghilangkan pesan error
error_reporting(0);

?>


 <!--ini koding untuk edit data-->
 <?php
		//jika sudah mendapatkan parameter GET id dari URL
		if(isset($_GET['id'])){
			//membuat variabel $id untuk menyimpan id dari GET id di URL
			$id = $_GET['id'];
			
			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM user WHERE id_user='$id'") or die(mysqli_error($koneksi));
			
			//jika hasil query = 0 maka muncul pesan error
			if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
		}
		?>


<?php

  //saat tombol simpan ditindis
  if(isset($_POST['tambah']))
  {
        $nama       = $_POST['nama'];
        $username   = $_POST['username'];
        $password   = md5($_POST['password']);
        $level      = $_POST['level'];


        //buat dan jalankan query INSERT
        $ambil = mysqli_query($koneksi, "UPDATE user SET 
        fullname='$nama',
        username='$username', 
        password='$password', 
        level='$level' WHERE id_user='$id' ") or die(mysqli_error($koneksi));
                
        if($ambil){
          echo '<script>alert("Berhasil mengubah data."); document.location="user.php";</script>';
        }else{
          echo '<div class="alert alert-warning">Gagal melakukan proses edit data.</div>';
        }
      }
      
    ?>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Edit User Akases</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->

                    
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-12 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="edit_user.php?id=<?php echo $id;?>" method="post">
                                    <div class="form-group">
                                        <label class="col-md-12">Full Name</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="nama"  value="<?php echo $pecahkan['fullname']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Username</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="username"  value="<?php echo $pecahkan['username']; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Password</label>
                                        <div class="col-md-12">
                                            <input type="password" class="form-control form-control-line" name="password">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-12">Status Hak Akses</label>
                                        <div class="col-sm-12">
                                            <select class="form-control form-control-line" name="level">
                                                <option value="admin" <?php if($pecahkan['level'] == 'admin'){ echo 'selected'; } ?>>Admin</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button class="btn btn-success" name="tambah">Tambahkan User</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>

<?php

include "footer.php";
?>
<?php

include "head.php";
include "menu.php";

//menghilangkan pesan error
error_reporting(0);

?>


 <!--ini koding untuk edit data-->
 <?php
		//jika sudah mendapatkan parameter GET id dari URL
		if(isset($_GET['id'])){
			//membuat variabel $id untuk menyimpan id dari GET id di URL
			$id = $_GET['id'];
			
			//query ke database SELECT tabel jemaat berdasarkan id = $id
			$select = mysqli_query($koneksi, "SELECT * FROM beli WHERE id_beli='$id'") or die(mysqli_error($koneksi));
			
			//jika hasil query = 0 maka muncul pesan error
			if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$pecahkan = mysqli_fetch_assoc($select);
			}
		}
		?>


<?php

  //saat tombol simpan ditindis
  if(isset($_POST['ubah']))
  {
        $status       = $_POST['status'];

        //buat dan jalankan query INSERT
        $ambil = mysqli_query($koneksi, "UPDATE beli SET 

        status='$status' WHERE id_beli='$id' ") or die(mysqli_error($koneksi));
                
        if($ambil){
          echo '<script>alert("Berhasil mengubah status."); document.location="laporan_transaksi.php";</script>';
        }else{
          echo '<div class="alert alert-warning">Gagal mengubah status.</div>';
        }
      }
      
    ?>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Konfirmasi Pembelian</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->

                    
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="konfirmasi.php?id=<?php echo $id;?>" method="post">
                                    <div class="form-group">
                                        <label class="col-sm-12">Ubah Status</label>
                                        <div class="col-sm-12">
                                            <select class="form-control form-control-line" name="status">
                                                <option  value="lunas" <?php if($pecahkan['status'] == 'ditanggapi'){ echo 'selected'; } ?>>Lunas</option>
                                                <option  value="belum" <?php if($pecahkan['status'] == 'belum'){ echo 'selected'; } ?>>Belum Lunas</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button class="btn btn-success" name="ubah">Ubah Status</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>

<?php

include "footer.php";
?>
<?php

include "head.php";
include "menu.php";

?>

<?php

  //saat tombol simpan ditindis
  if(isset($_POST['tambah']))
  {
        $nama       = $_POST['nama'];
        $username   = $_SESSION['username'];;
        $warna      = $_POST['warna'];
        $jumlah     = $_POST['jumlah'];
        $harga      = $_POST['harga'];
        $total      = $harga * $jumlah;
        $status      = $_POST['status'];
        $level      = $_POST['level'];

    //buat dan jalankan query INSERT
    $query = "INSERT INTO beli ";
    $query .= "(nama_produk, username, warna, jumlah, total_harga, status, level)";
    $query .= "VALUES('$nama','$username','$warna','$jumlah','$total','$status','$level')";

    echo "<script>alert('Pembelian Berhasil Dilakukan')</script>";
    echo "<script>location='kasir.php'</script>";

    $result = mysqli_query($koneksi, $query);

    if(!$result)
    {
      die("Query gagal dijalankan: ".mysqli_errno($koneksi) ." - " .mysqli_error($koneksi));

    }
  }

?>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Tambah Pembelian Produk</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->

                    
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="tambah_produk_terjual.php" method="post">
                                    <div class="form-group">
                                        <label class="col-md-12">Nama Produk</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="nama">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Harga (Rp.)</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="harga">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Jumlah (pcs)</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="jumlah">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-12">Warna</label>
                                        <div class="col-sm-12">
                                            <select class="form-control form-control-line" name="warna">
                                                <option value="merah">Merah</option>
                                                <option value="putih">Putih</option>
                                                <option value="pink">Pink</option>
                                                <option value="kuning">Kuning</option>
                                            </select>
                                        </div>
                                    </div>
                                    <input type="hidden" class="form-control form-control-line" name="status" value="lunas">
                                    <input type="hidden" class="form-control form-control-line" name="level" value="<?php echo $_SESSION['level'];?>">
                                        
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button class="btn btn-success" name="tambah">Tambahkan Pembelian</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>

<?php

include "footer.php";
?>
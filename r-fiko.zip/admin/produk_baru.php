<?php

include "head.php";
include "menu.php";

?>

<?php

  //saat tombol simpan ditindis
  if(isset($_POST['tambah']))
  {
        $subject        = $_POST['subject'];
        $harga          = $_POST['harga'];
        $deskripsi      = $_POST['deskripsi'];
        $kategori       = $_POST['kategori'];
        $link1          = $_POST['link1'];
        $link2          = $_POST['link2'];

    // Ambil Data yang Dikirim dari Form
$nama_file = $_FILES['gambar']['name'];
$ukuran_file = $_FILES['gambar']['size'];
$tipe_file = $_FILES['gambar']['type'];
$tmp_file = $_FILES['gambar']['tmp_name'];

// Set path folder tempat menyimpan gambarnya
$path = "../foto_produk/".$nama_file;

if($tipe_file == "image/jpeg" || $tipe_file == "image/png"){ // Cek apakah tipe file yang diupload adalah JPG / JPEG / PNG
	// Jika tipe file yang diupload JPG / JPEG / PNG, lakukan :
	if($ukuran_file <= 1000000){ // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
		// Jika ukuran file kurang dari sama dengan 1MB, lakukan :
		// Proses upload
		if(move_uploaded_file($tmp_file, $path)){ // Cek apakah gambar berhasil diupload atau tidak

    //buat dan jalankan query INSERT
    $query = "INSERT INTO jualan ";
    $query .= "(subject, harga, deskripsi, foto, ukuran, tipe, kategori, link1, link2)";
    $query .= "VALUES('$subject','$harga','$deskripsi','$nama_file','$ukuran_file','$tipe_file','$kategori','$link1','$link2')";

    echo "<script>alert('Data Berhasil Ditambah')</script>";
    echo "<script>location='data_produk.php'</script>";
      
			if($sql){ // Cek jika proses simpan ke database sukses atau tidak
				// Jika Sukses, Lakukan :
				header("location: data_produk.php"); // Redirectke halaman index.php
			}else{
				// Jika Gagal, Lakukan :
				echo "<script>alert('Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.')</script>";
				echo "<script>location='data_produk.php'</script>";
			}
		}else{
			// Jika gambar gagal diupload, Lakukan :
      echo "<script>alert('Maaf, Gambar gagal untuk diupload.')</script>";
      echo "<script>location='data_produk.php'</script>";
		}
	}else{
		// Jika ukuran file lebih dari 1MB, lakukan :
    echo "<script>alert('Maaf, Ukuran gambar yang diupload tidak boleh lebih dari 1MB')</script>";
    echo "<script>location='data_produk.php'</script>";
	}
}else{
  // Jika tipe file yang diupload bukan JPG / JPEG / PNG, lakukan :
  echo "<script>alert('Maaf, Tipe gambar yang diupload harus JPG / JPEG / PNG.')</script>";
  echo "<script>location='data_produk.php'</script>";
}
    $result = mysqli_query($koneksi, $query);

    if(!$result)
    {
      die("Query gagal dijalankan: ".mysqli_errno($koneksi) ." - " .mysqli_error($koneksi));

    }
  }

?>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Buat Baru Jualan</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->

                    
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <form class="form-horizontal form-material" enctype="multipart/form-data" action="produk_baru.php" method="post">
                                    <div class="form-group">
                                        <label class="col-md-12">Subject</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="subject">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Harga (Rp)</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="harga">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Deskripsi</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="deskripsi">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Foto</label>
                                        <div class="col-md-12">
                                            <input type="file" class="form-control form-control-line" name="gambar">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Link 1 (Foto)</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="link1">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Link 2 (Foto)</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="link2">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-12">Kategori</label>
                                        <div class="col-sm-12">
                                            <select class="form-control form-control-line" name="kategori">
                                                <option value="promo">Promo</option>
                                                <option value="diskon">Diskon</option>
                                                <option value="normal">Normal</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button class="btn btn-success" name="tambah">Jual Sekarang</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>

<?php

include "footer.php";
?>
<?php

include "head.php";
include "menu.php";

?>
<?php
$postingan   = mysqli_query($koneksi,"SELECT * FROM jualan"); 
$beli = mysqli_query($koneksi, "SELECT SUM(total_harga) AS total FROM beli WHERE statusku='lunas'") or die(mysqli_error());
$item = mysqli_query($koneksi, "SELECT SUM(jumlah) AS total FROM beli") or die(mysqli_error());
$pembeli   = mysqli_query($koneksi,"SELECT * FROM pembeli"); 

$jumlahpostingan = mysqli_num_rows($postingan);
$jumlahbeli = mysqli_fetch_array($beli);
$jumlahitem = mysqli_fetch_array($item);
$jumlahpembeli = mysqli_num_rows($pembeli);
?>

<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#"></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                    </div>
                </div>
            </div>
<div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Informasi Pendataan</h4>
                                <div class="feed-widget">
                                    <ul class="list-style-none feed-body m-0 p-b-20">
                                        <li class="feed-item">
                                            <div class="feed-icon bg-info"><i class="far fa-bell"></i></div> Jumlah Postingan Jualan <span class="ml-auto font-12 text-muted"><?php echo number_format($jumlahpostingan,0,",",".");  ?></span></li>
                                        <li class="feed-item">
                                            <div class="feed-icon bg-success"><i class="ti-server"></i></div> Total Pendapatan<span class="ml-auto font-12 text-muted">Rp. <?php echo $jumlahbeli['total']?></span></li>
                                        <li class="feed-item">
                                            <div class="feed-icon bg-warning"><i class="ti-shopping-cart"></i></div> Jumlah Produk Terjual<span class="ml-auto font-12 text-muted"><?php echo $jumlahitem ['total']?></span></li>
                                        <li class="feed-item">
                                            <div class="feed-icon bg-danger"><i class="ti-user"></i></div> Jumlah Akun Pembeli<span class="ml-auto font-12 text-muted"><?php echo number_format($jumlahpembeli,0,",",".");  ?></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-body">
                                <center>
                                    <h3 class="card-title">Selamat datang di</h3>
                                    <h1><?php  echo $webidentitas['judul_website'] ;?></h1>
                                </center>
                                <div class="feed-widget">
                                <!--<img src="../images/toko-bunga-bandung4.jpg" height="277px" width="670px">--->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->
               


            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
<?php

include "footer.php";
?>
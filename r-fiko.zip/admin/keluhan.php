<?php

include "head.php";
include "menu.php";

?>

<?php

  //saat tombol simpan ditindis
  if(isset($_POST['status']))
  {
        $status        = $_POST['status'];

            //buat dan jalankan query INSERT
    $query = "INSERT INTO keluhan ";
    $query .= "(status)";
    $query .= "VALUES('$status')";

    echo "<script>alert('Status berhasil diubah')</script>";
    echo "<script>location='keluhan.php'</script>";      
  }

?>
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                          <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->

                    
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-12 col-xlg-9 col-md-7">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!-- title -->
                                <div class="d-md-flex align-items-center">
                                    <div>
                                        <h4 class="card-title">Ulasan / Keluhan</h4>
                                    </div>
                                    <div class="ml-auto">
                                        <div class="dl">              
                                        </div>
                                    </div>
                                </div>
                                <!-- title -->
                            </div>
                            <div class="table-responsive">
                            <form method="post" action="#">
                                <table id="tabel-data" class="table v-middle">
                                    <thead>
                                        <tr class="bg-light">
                                            <th class="border-top-0">No.</th>
                                            <th class="border-top-0">Nama Pelapor</th>
                                            <th class="border-top-0">Email</th>
                                            <th class="border-top-0">Telepon</th>
                                            <th class="border-top-0">Ulasan / Keluhan</th>
                                            <th class="border-top-0">Status Keluhan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $nomor=1; //mengurutkan nomor , sambungan ++ dibawah

                                        $ambil = mysqli_query($koneksi, "SELECT * FROM keluhan") or die(mysqli_error($koneksi)); //mengambil query pada tabel jemaat
                                        
                                        while($pecahkan = mysqli_fetch_assoc($ambil)){ //perulangan 

                                        ?>
                                    
                                        
                                            <tr>
                                            <td> <?php echo $nomor;?> </td>
                                            <td> <?php echo $pecahkan['nama'];?> </td>
                                            <td> <?php echo $pecahkan['email'];?> </td>
                                            <td> <?php echo $pecahkan['telepon'];?> </td>
                                            <td> <?php echo $pecahkan['keluhan'];?> </td>
                                            <td> 
                                                <?php
                                                      if(isset($pecahkan['status'])){
                                                        if($pecahkan['status'] == "ditanggapi"){
                                                            
                                                            echo "<a href='#' class='btn btn-info btn-sm' name='status' value='belum'>Sudah Ditanggapi</a>";
                                                    
                                                        }
                                                          else {
                                                            $id_keluhan = $pecahkan['id_keluhan'];
                                                           echo "<a href='edit_keluhan.php?id=$id_keluhan' class='btn btn-danger btn-sm' name='status' value='ditanggapi'>Belum Ditanggapi</a>";
                                                          }
                                                        }
                                                ?>
                                                         
                                            </td>
                                            </tr>
                                        
                                            <?php $nomor++; //untuk menambah 1 angka untuk nomor urut?>
                                    <?php } ?>

  
                     </tbody>
                     <!--ini depe script data table-->
                          <script>
                          $(document).ready(function(){
                              $('#tabel-data').DataTable();
                          });
                      </script>

                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
<?php

include "footer.php";
?>
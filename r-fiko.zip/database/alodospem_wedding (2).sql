-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2023 at 01:46 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alodospem_wedding`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `beli`
--

CREATE TABLE `beli` (
  `id_beli` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_harga` varchar(255) NOT NULL,
  `statusku` varchar(15) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `beli`
--

INSERT INTO `beli` (`id_beli`, `nama_produk`, `username`, `jumlah`, `total_harga`, `statusku`, `level`) VALUES
(25, 'Gaun Wedding Lengkap', 'fikopembeli', 2, '7000000', 'lunas', 'pembeli'),
(27, 'Gaun Wedding Lengkap', 'fikopembeli', 1, '7000000', 'lunas', 'pembeli'),
(28, 'Dekorasi Pernikahan', 'fikopembeli', 1, '3000000', 'keranjang', 'pembeli');

-- --------------------------------------------------------

--
-- Table structure for table `jualan`
--

CREATE TABLE `jualan` (
  `id_jual` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL,
  `deskripsi` text NOT NULL,
  `foto` varchar(100) NOT NULL,
  `ukuran` int(11) NOT NULL,
  `tipe` varchar(20) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `link1` varchar(255) NOT NULL,
  `link2` varchar(255) NOT NULL,
  `post_jasa` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jualan`
--

INSERT INTO `jualan` (`id_jual`, `subject`, `harga`, `deskripsi`, `foto`, `ukuran`, `tipe`, `kategori`, `link1`, `link2`, `post_jasa`) VALUES
(12, 'Dekorasi Pernikahan ', 3000000, '<p>Tidak ada pernikahan yang benar-benar lengkap tanpa adanya dekorasi pernikahan. Walaupun sederhana, dekorasi dapat mengubah acara khusus menjadi perayaan yang sempurna. Sebuah pesta sekali dalam seumur hidup yang selalu Anda impikan. </p><p>Sekarang ini, dekorasi dalam pernikahan tidaklah mudah, dibutuhkan banyak pertimbangan dan persiapan yang matang. Jadi, sebelum Anda memutuskan untuk mencari ide dekorasi pernikahan, lengkapi diri Anda dengan pengetahuan dasar soal dekorasi.</p><p>Anda tidak perlu khawatir, kami toko holioa bisa mengatasi masalah dekorasi pernikahan hanya untuk anda saja.</p>', '279620913_336508821884450_5541382363871314525_n.jpg', 39732, 'image/jpeg', 'promo', 'https://i0.wp.com/idewedding.com/wp-content/uploads/2021/01/Konsep-Dekorasi-Pelaminan-Minimalis-Untuk-Outdoor.jpg?fit=1080%2C1350&ssl=1', 'https://weddingmarket.com/storage/images/artikelidea/c4910877d559cde9774d6fc26b045bd39098849b.webp', 'dekorasi-pernikahan'),
(13, 'Gaun Wedding Lengkap', 7000000, '<p>Salah satu hal yang penting dalam pernikahan adalah menyiapkan gaun pengantin, terutama bagi calon mempelai wanita. Banyak pertimbangan untuk memilih apakah sebaiknya menyewa saja, membelinya, atau malah membuat sendiri baju pengantin sesuai keinginanmu. </p><p>Hal ini tentu saja kembali pada kebutuhanmu, Jika kamu ingin gaun pengantinmu berbeda dari yang lain, maka sebaiknya kamu membelinya saja. Namun, jika budget-mu tidak cukup, ada baiknya memilih untuk menyewa saja.</p><p>Kami Toko hailoa menyediakan perlengkapan gaun wedding yang lengkap dan murah.</p>', '279621513_733004308136274_5122387956410149468_n.jpg', 37863, 'image/jpeg', 'promo', 'https://cdn.popmama.com/content-images/post/20200708/potrait-popmama-800-x-999-2020-07-08t174416691jpg-cb3cd8e474d878701e68831742b8b7d8_600xauto.jpg', 'https://images.unsplash.com/photo-1603651308320-8006d20255c3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8d2VkZGluZyUyMGluZG9uZXNpYXxlbnwwfHwwfHw%3D&w=1000&q=80', 'gaun-wedding-lengkap');

-- --------------------------------------------------------

--
-- Table structure for table `keluhan`
--

CREATE TABLE `keluhan` (
  `id_keluhan` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telepon` varchar(255) NOT NULL,
  `keluhan` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `bintang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `keluhan`
--

INSERT INTO `keluhan` (`id_keluhan`, `nama`, `email`, `telepon`, `keluhan`, `status`, `bintang`) VALUES
(1, 'Keluarga Berencana', 'apasih@gmail.com', '849e82932', 'Puas dengan layanan dari toko hailoa', 'ditanggapi', 5),
(2, 'Nambah Lagi', 'maleleh@gmail.com', '0813xxxxx', 'Thx gan', 'belum', 5);

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `id_pembeli` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`id_pembeli`, `fullname`, `username`, `password`, `level`, `email`, `alamat`, `telepon`) VALUES
(2, 'pembeli', 'karyawan', '9e014682c94e0f2cc834bf7348bda428', 'pembeli', '', 'Bahu', '081358583737'),
(7, 'Fiko Aja Deh', 'fikopembeli', '4690497c8265508a7f2c9c90082f69d0', 'pembeli', 'fikopembeli@gmail.com', 'Jl Sulawesi No 84', '089364525'),
(8, 'asasa', 'test', '098f6bcd4621d373cade4e832627b4f6', 'pembeli', 'teststfficer@gmail.com', 'asasas', '081241467206');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id_setting` int(11) NOT NULL,
  `judul_website` varchar(255) NOT NULL,
  `nama_rek1` varchar(255) NOT NULL,
  `nomor_rek1` varchar(255) NOT NULL,
  `nama_rek2` varchar(255) NOT NULL,
  `nomor_rek2` varchar(255) NOT NULL,
  `link_web` varchar(255) NOT NULL,
  `youtube` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id_setting`, `judul_website`, `nama_rek1`, `nomor_rek1`, `nama_rek2`, `nomor_rek2`, `link_web`, `youtube`) VALUES
(1, 'Rancang Bangun Aplikasi Toko Hailoa Studio Untuk Event Organizer Wedding Berbasis Web', '46373 26362', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `fullname`, `username`, `password`, `level`) VALUES
(7, 'Rian Fiko', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `beli`
--
ALTER TABLE `beli`
  ADD PRIMARY KEY (`id_beli`),
  ADD KEY `id_pembeli` (`username`);

--
-- Indexes for table `jualan`
--
ALTER TABLE `jualan`
  ADD PRIMARY KEY (`id_jual`);

--
-- Indexes for table `keluhan`
--
ALTER TABLE `keluhan`
  ADD PRIMARY KEY (`id_keluhan`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`id_pembeli`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id_setting`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `beli`
--
ALTER TABLE `beli`
  MODIFY `id_beli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `jualan`
--
ALTER TABLE `jualan`
  MODIFY `id_jual` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `keluhan`
--
ALTER TABLE `keluhan`
  MODIFY `id_keluhan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembeli`
--
ALTER TABLE `pembeli`
  MODIFY `id_pembeli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id_setting` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

// koneksi ke mysql (database)
$koneksi = mysqli_connect("localhost","root","","alodospem_wedding");

if (!$koneksi)
    {
        die ("Gagal Koneksi: ".mysqli_connect_errno(). " _ ".mysqli_connect_error());
    }

?>
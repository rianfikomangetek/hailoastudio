<?php 
// mengaktifkan session pada php
session_start();



//jika sudah login tak bisa kembali kemari
if (isset($_SESSION["level"])) {
	header("Location: pembeli/index.php");
	exit;
}

// menghubungkan php dengan koneksi database
include 'koneksi.php';


// menangkap data yang dikirim dari form login
$namauser = $_POST['username'];
$username = mysqli_real_escape_string($koneksi, $namauser);

$kodepassword = md5($_POST['password']);
$password = mysqli_real_escape_string($koneksi, $kodepassword);


// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"select * from pembeli where username='$username' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password di temukan pada database
if($cek > 0){

	$data = mysqli_fetch_assoc($login);
	
	$_SESSION["level"] = $data;
	// cek jika user login sebagai admin
	if($data['level']=="pembeli"){

		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "pembeli";
		// alihkan ke halaman dashboard admin
		header("location:pembeli/index.php");
	
	}else{

		// alihkan ke halaman login kembali
		header("location:login.php?pesan=gagal");
	}

	
}else{
	header("location:login.php?pesan=gagal");
}



?>
<?php

	include 'head.php';
	include 'menu.php';
?>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_5.jpg);">
		<div class="overlay"></div>
		<div class="fh5co-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Login</h1>
							<h2>Login dengan akun anda untuk melakukan pembelian</h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>


	<div class="fh5co-section">
		<div class="container">
			<div class="row">
				
				<div class="col-md-6 col-md-push-6 animate-box">
					<h3>Login</h3>
					<form action="cek_login_pembeli.php" method="post" class="login100-form validate-form">
				
					<?php 
					if(isset($_GET['pesan'])){
						if($_GET['pesan']=="gagal"){
							echo "<div class='alert alert-danger'>Aduh!!! Login Gagal</div>";
						}
					}

					if(isset($_GET['pesan'])){
						if($_GET['pesan']=="validasi"){
							echo "<div class='alert alert-warning'>Anda harus login terlebih dahulu</div>";
						}
					}
					?>
						

						<div class="row form-group">
							<div class="col-md-12">
								<label for="email">Username</label>
								<input type="text" id="email" class="form-control" name="username" placeholder="Username">
							</div>
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label for="subject">Password</label>
								<input type="text" id="subject" class="form-control" name="password" placeholder="Kata Sandi">
							</div>
						</div>

					
						<div class="form-group">
							<input type="submit" value="Login" class="btn btn-primary">
						</div>

					</form>		
				</div>
				<div class="col-md-5 col-md-pull-5 animate-box">
					
					<div class="fh5co-contact-info">
					<div class="couple-wrap animate-box">
				<div class="couple-half">
					<div class="groom">
						<img src="images/groom.jpg" alt="groom" class="img-responsive">
					</div>
	
				</div>
				<p class="heart text-center"><i class="icon-heart2"></i></p>
				<div class="couple-half">
					<div class="bride">
						<img src="images/bride.jpg" alt="groom" class="img-responsive">
					</div>
			
				</div>
			</div>
					</div>

				</div>
			</div>
			
		</div>
	</div>

	<div id="map" class="fh5co-map"></div>
		<!-- END map -->

<?php include 'footer.php';?>
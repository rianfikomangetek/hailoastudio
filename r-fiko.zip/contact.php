<?php

	include 'head.php';
	include 'menu.php';

?>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(images/img_bg_1.jpg);">
		<div class="overlay"></div>
		<div class="fh5co-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Tentang Kami </h1>
						<div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div id="fh5co-couple" class="fh5co-section-gray">
		<div class="container">
			
			<div class="couple-wrap animate-box">
				<div class="couple">					
					<div class="desc-bride">
						<h3>Kontak</h3>
						<p>Terima kasih anda telah memilih jasa wedding organizer toko Hailoa. Jika anda memiliki sebuah
							kritik, saran atau masukan guna meningkatkan pelayaran dan kinerja kami, anda bisa menghubungi kami melalui email di bawah
							<br>
							<a href="mailto:tokohailoa@gmail.com" class="btn btn-info">Email</a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	

	
	<?php
		include 'footer.php';
	?>


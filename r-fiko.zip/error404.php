<?php

	include 'head.php';
	include 'menu.php';

?>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="height:100px;">
		<div class="overlay"></div>
			<div class="fh5co-container">
			
			</div>
		</div>
	</header>

	<div id="fh5co-couple" class="fh5co-section-gray">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
					<h2>ERROR 404</h2>
					<h3>Tidak ditemukan halaman yang anda cari!</h3>
				</div>
			</div>
			
		</div>
	</div>

	

	
	<?php
		include 'footer.php';
	?>

